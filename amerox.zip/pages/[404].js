import React from "react";

//INTERNAL IMPORT
import { NoPage } from "../components/index";

const noPage = () => {
  return <NoPage />;
};

export default noPage;
